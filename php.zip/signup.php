<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Registration</title>
<script type="text/JavaScript">
<!--

//-->
</script>
</head>

<body>

<form action="process.php" method="post" >

<table width="40%" border="0" align="center" cellpadding="3px" style="border:solid thin">
  <tr>
    <td width="32%">User name </td>
    <td width="1%">&nbsp;</td>
    <td><input type="text" name="user" /></td>
  </tr>
  <tr>
    <td>Address</td>
    <td>&nbsp;</td>
    <td><input type="text" name="address" /></td>
  </tr>
  <tr>
    <td>Ohd E-mail</td>
    <td>&nbsp;</td>
    <td><input type="text" name="o-email" />
      <strong>@vikram.net</strong></td>
  </tr>
  <tr>
    <td>Password</td>
    <td>&nbsp;</td>
    <td><input type="password" name="pass" /></td>
  </tr>
  <tr>
    <td>Confirm password</td>
    <td>&nbsp;</td>
    <td><input type="password" name="pass2" /></td>
  </tr>
  <tr>
    <td>Date of birth</td>
    <td>&nbsp;</td>
    <td><table width="100%" border="0">
      <tr>
        <td>
          <select name="bdate" >
		  <?php
		   for ( $i=1;$i<=31; $i++)
            echo "<option value='$i' >". $i ."</option>"
		   ?>
          </select>
                �  </td>
        <td><select size="1" name="bmonth">
          <option value="1">JAN</option>
          <option value="2">FEB</option>
          <option value="3">MAR</option>
          <option value="4">APR</option>
          <option value="5">MAY</option>
          <option value="6">JUN</option>
          <option value="7">JUL</option>
          <option value="8">AUG</option>
          <option value="9">SEP</option>
          <option value="10">OCT</option>
          <option value="11">NOV</option>
          <option value="12">DEC</option>
        </select></td>
        <td>
          <select name="byear" >
           <?php
		   for ( $i=1960;$i<=2000; $i++)
            echo "<option value='$i' >". $i ."</option>"
		   ?>
          </select>        
        </td>
		<td width="20%">&nbsp; </td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>Gender</td>
    <td>&nbsp;</td>
    <td><table width="100%" border="0">
      <tr>
        <td align="left">male
          <input name="gender" type="radio" value="male" /></td><td width="35%">female
            <input name="gender" type="radio" value="female" />
</td>
        <td align="left" width="35%">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>Status of Profession </td>
    <td>&nbsp;</td>
    <td>
      <select name="menu2">
        <option>--profession--</option>
		<option value="student">student</option>
		<option value="principal">principal</option>
		<option value="hod">hod</option>
		<option value="lecturer">lecturer</option>
		
      </select>
   
    </td>
  </tr>
  <tr>
    <td>Department</td>
    <td>&nbsp;</td>
    <td>
      <select name="menu3" >
        <option>--department-</option>
		<option value="cse">cse</option>
		<option value="eee">eee</option>
		<option value="it">it</option>
		<option value="ece">ece</option>
		<option value="mech">mech</option>
      </select>
    
    </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><table width="100%" border="0">
      <tr>
        <td align="left"><input type="reset" name="Submit2" value="reset" />
          <input type="submit" name="submit" value="register" /></td>
        <td width="40%">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</form>

</body>
</html>
