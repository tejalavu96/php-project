<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="File-List" href="your_ohd_home_page_files/filelist.xml">

<title>YOUR OHD HOME PAGE</title>
<!--[if !mso]>
<style>
v\:*         { behavior: url(#default#VML) }
o\:*         { behavior: url(#default#VML) }
.shape       { behavior: url(#default#VML) }
</style>
<![endif]--><!--[if gte mso 9]>
<xml><o:shapedefaults v:ext="edit" spidmax="1027"/>
</xml><![endif]-->
</head>

<body bgcolor="#00FFFF">

<p><b><font size="5">YOUR OHD</font><font size="5"> HOME PAGE:&nbsp;&nbsp;&nbsp;
<img border="0" src="56534520_1df05440fb[1].jpg" width="105" height="75"></font></b></p>
<p>&nbsp;</p>
<p align="center"><font color="#800000"><b>OHD OFFERING YOU A COMMON HOME PAGE 
IF YOU WANT TO COMPOSE OR TO VIEW THE REQUEST PLEASE LOGIN TO THE MAILING FORM</b></font></p>
<p align="center"><font color="#800000"><b><marquee>OHD IS USED TO SEND OUR REQUEST 
TO THE RESPECTED OFFICIAL</marquee></b></font></p>
<HR color="#800000" align="left"></HR>
<p><b><font size="2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </font>
CATEGORIES&nbsp; :&nbsp; </b></p>
<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
HOME&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; HOME PAGE OF OHD&nbsp; </b></p>
<div align="right" style="width: 229; height: 175; border-style: solid; border-width: 1; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1">
  <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse; border-width: 0" bordercolor="#111111" width="221" height="15" id="AutoNumber1">
    <tr>
      <td width="221" height="15" style="border-style: none; border-width: medium">
      <p align="center"><!--[if gte vml 1]><v:shapetype id="_x0000_t165"
 coordsize="21600,21600" o:spt="165" adj="10125" path="m,c7200@0,14400@0,21600,m,21600r21600,e">
 <v:formulas>
  <v:f eqn="prod #0 4 3"/>
  <v:f eqn="val #0"/>
  <v:f eqn="prod #0 2 3"/>
  <v:f eqn="sum 21600 0 @2"/>
 </v:formulas>
 <v:path textpathok="t" o:connecttype="custom" o:connectlocs="10800,@1;0,10800;10800,21600;21600,10800"
  o:connectangles="270,180,90,0"/>
 <v:textpath on="t" fitshape="t" xscale="t"/>
 <v:handles>
  <v:h position="center,#0" yrange="0,20250"/>
 </v:handles>
 <o:lock v:ext="edit" text="t" shapetype="t"/>
</v:shapetype><v:shape id="_x0000_s1029" type="#_x0000_t165" style='width:35.25pt;
 height:22.5pt' fillcolor="gray" strokeweight="1pt">
 <v:fill src="your_ohd_home_page_files/image001.gif" o:title="Narrow vertical"
  color2="yellow" type="pattern"/>
 <v:shadow on="t" opacity="52429f" offset="3pt"/>
 <v:textpath style='font-family:"Arial Black";font-size:10pt;v-text-kern:t'
  trim="t" fitpath="t" xscale="f" string="LOGIN"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=52 height=35
src="your_ohd_home_page_files/image002.gif" alt=LOGIN v:shapes="_x0000_s1029"><![endif]></p>
      <form method="POST" action="--WEBBOT-SELF--">
        <!--webbot bot="SaveResults" u-file="C:\Documents and Settings\Administrator\My Documents\My Webs\_private\form_results.csv" s-format="TEXT/CSV" s-label-fields="TRUE" --><p align="center">
        E-MAIL &gt;&gt; <input type="text" name="T1" size="20"></p>
      </form>
      <p align="center">PASSWORD&gt;&gt;</p>
      <form method="POST" action="--WEBBOT-SELF--">
        <!--webbot bot="SaveResults" u-file="C:\Documents and Settings\Administrator\My Documents\My Webs\_private\form_results.csv" s-format="TEXT/CSV" s-label-fields="TRUE" --><p align="center">
        <input type="text" name="T1" size="20"></p>
      </form>
      <form method="POST" action="--WEBBOT-SELF--">
        <!--webbot bot="SaveResults" u-file="C:\Documents and Settings\Administrator\My Documents\My Webs\_private\form_results.csv" s-format="TEXT/CSV" s-label-fields="TRUE" --><p align="center">
        <input type="submit" value="Submit" name="B1"></p>
      </form>
      </td>
    </tr>
  </table>
</div>
<p> </HR>&nbsp;<p>&nbsp;</p>
<p>&nbsp;</p>
<hr noshade color="#800000">
<p><!--[if gte vml 1]><v:shapetype
 id="_x0000_t103" coordsize="21600,21600" o:spt="103" adj="12960,19440,7200"
 path="wr@22,0@21@3,,0@21@4@22@14@21@1@21@7@2@12l@2@13,0@8@2@11at@22,0@21@3@2@10@24@16@22@14@21@1@24@16,0@14xear@22@14@21@1@21@7@24@16nfe">
 <v:stroke joinstyle="miter"/>
 <v:formulas>
  <v:f eqn="val #0"/>
  <v:f eqn="val #1"/>
  <v:f eqn="val #2"/>
  <v:f eqn="sum #0 width #1"/>
  <v:f eqn="prod @3 1 2"/>
  <v:f eqn="sum #1 #1 width"/>
  <v:f eqn="sum @5 #1 #0"/>
  <v:f eqn="prod @6 1 2"/>
  <v:f eqn="mid width #0"/>
  <v:f eqn="ellipse #2 height @4"/>
  <v:f eqn="sum @4 @9 0"/>
  <v:f eqn="sum @10 #1 width"/>
  <v:f eqn="sum @7 @9 0"/>
  <v:f eqn="sum @11 width #0"/>
  <v:f eqn="sum @5 0 #0"/>
  <v:f eqn="prod @14 1 2"/>
  <v:f eqn="mid @4 @7"/>
  <v:f eqn="sum #0 #1 width"/>
  <v:f eqn="prod @17 1 2"/>
  <v:f eqn="sum @16 0 @18"/>
  <v:f eqn="val width"/>
  <v:f eqn="val height"/>
  <v:f eqn="sum 0 0 height"/>
  <v:f eqn="sum @16 0 @4"/>
  <v:f eqn="ellipse @23 @4 height"/>
  <v:f eqn="sum @8 128 0"/>
  <v:f eqn="prod @5 1 2"/>
  <v:f eqn="sum @5 0 128"/>
  <v:f eqn="sum #0 @16 @11"/>
  <v:f eqn="sum width 0 #0"/>
  <v:f eqn="prod @29 1 2"/>
  <v:f eqn="prod height height 1"/>
  <v:f eqn="prod #2 #2 1"/>
  <v:f eqn="sum @31 0 @32"/>
  <v:f eqn="sqrt @33"/>
  <v:f eqn="sum @34 height 0"/>
  <v:f eqn="prod width height @35"/>
  <v:f eqn="sum @36 64 0"/>
  <v:f eqn="prod #0 1 2"/>
  <v:f eqn="ellipse @30 @38 height"/>
  <v:f eqn="sum @39 0 64"/>
  <v:f eqn="prod @4 1 2"/>
  <v:f eqn="sum #1 0 @41"/>
  <v:f eqn="prod height 4390 32768"/>
  <v:f eqn="prod height 28378 32768"/>
 </v:formulas>
 <v:path o:extrusionok="f" o:connecttype="custom" o:connectlocs="0,@15;@2,@11;0,@8;@2,@13;@21,@16"
  o:connectangles="180,180,180,90,0" textboxrect="@43,@41,@44,@42"/>
 <v:handles>
  <v:h position="topLeft,#0" yrange="@37,@27"/>
  <v:h position="topLeft,#1" yrange="@25,@20"/>
  <v:h position="#2,bottomRight" xrange="0,@40"/>
 </v:handles>
 <o:complex v:ext="view"/>
</v:shapetype><v:shape id="_x0000_s1031" type="#_x0000_t103" style='position:absolute;
 left:242.25pt;top:276pt;width:235.5pt;height:126pt;z-index:1'>
 <v:textbox>
<table cellspacing="0" cellpadding="0" width="100%" height="100%">
  <tr>
    <td align="center"><i><b><font size="4">FILL HERE</font></b></i></td>
  </tr>
</table>
 </v:textbox>
</v:shape><![endif]--><![if !vml]><span style='mso-ignore:vglayout;position:
absolute;z-index:1;left:320px;top:367px;width:322px;height:171px'><img
width=322 height=171 src="your_ohd_home_page_files/image003.gif"
alt="Curved Left Arrow: FILL HERE&#13;&#10;" v:shapes="_x0000_s1031"></span><![endif]>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</p>
<p><u><b>CATEGORIES OF DEPT FACULTIES AND THEIR DETAILS:</b></u></p>
<div align="right">
  <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="694" height="35" id="AutoNumber2">
    <tr>
      <td width="102" height="35">
      <p align="center"><font size="4"><b><i>
      <a href="IT.htm">IT</a></i></b></font></td>
      <td width="93" height="35" align="center">
      <p align="center"><i><b>
      <a href="CSE.htm">CSE</a></b></i></td>
      <td width="97" height="35" align="center">
      <p align="center"><b><i>
      <a href="ECE.htm">ECE</a></i></b></td>
      <td width="106" height="35" align="center"><b><i>
      <a href="EEE.htm">EEE</a></i></b></td>
      <td width="97" height="35" align="center"><b><i>
      <a href="mechanical_department.htm">MECH</a></i></b></td>
      <td width="97" height="35" align="center"><b><i>
      <a href="civil_department.htm">CIVIL</a></i></b></td>
      <td width="90" height="35" align="center"><b><i>
      <a href="AE.htm">AE</a></i></b></td>
    </tr>
  </table>
</div>
<p><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<HR color="#800000" align="left"></HR>&nbsp;&nbsp;&nbsp; 
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <!--[if gte vml 1]><v:shapetype
 id="_x0000_t136" coordsize="21600,21600" o:spt="136" adj="10800" path="m@7,l@8,m@5,21600l@6,21600e">
 <v:formulas>
  <v:f eqn="sum #0 0 10800"/>
  <v:f eqn="prod #0 2 1"/>
  <v:f eqn="sum 21600 0 @1"/>
  <v:f eqn="sum 0 0 @2"/>
  <v:f eqn="sum 21600 0 @3"/>
  <v:f eqn="if @0 @3 0"/>
  <v:f eqn="if @0 21600 @1"/>
  <v:f eqn="if @0 0 @2"/>
  <v:f eqn="if @0 @4 21600"/>
  <v:f eqn="mid @5 @6"/>
  <v:f eqn="mid @8 @5"/>
  <v:f eqn="mid @7 @8"/>
  <v:f eqn="mid @6 @7"/>
  <v:f eqn="sum @6 0 @5"/>
 </v:formulas>
 <v:path textpathok="t" o:connecttype="custom" o:connectlocs="@9,0;@10,10800;@11,21600;@12,10800"
  o:connectangles="270,180,90,0"/>
 <v:textpath on="t" fitshape="t"/>
 <v:handles>
  <v:h position="#0,bottomRight" xrange="6629,14971"/>
 </v:handles>
 <o:lock v:ext="edit" text="t" shapetype="t"/>
</v:shapetype><v:shape id="_x0000_s1032" type="#_x0000_t136" style='width:228pt;
 height:33pt' fillcolor="#60c" strokecolor="#c9f">
 <v:fill color2="#c0c" focus="100%" type="gradient"/>
 <v:shadow on="t" color="#99f" opacity="52429f" offset="3pt,3pt"/>
 <v:textpath style='font-family:"Impact";font-size:18pt;v-text-kern:t' trim="t"
  fitpath="t" string="PHOTO GALLERY OF THE MEMBERS"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=309 height=49
src="your_ohd_home_page_files/image004.gif" alt="PHOTO GALLERY OF THE MEMBERS"
v:shapes="_x0000_s1032"><![endif]>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
</b>
<p>&nbsp;&nbsp;<img name="" src="vickram.jpg" width="155" height="178" alt="" style="background-color: #AAFFFF">&nbsp;&nbsp;&nbsp;&nbsp;<img name="HELP" src="help[1].jpg" width="182" height="178" alt="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img name="HELP" src="writing450.jpg" width="183" height="182" alt=""></p>
<b>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</p>
</b>
</p>
</body>

</html>