<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Login</title>
</head>
<body topmargin="3" leftmargin="2" >

<p align="center">&nbsp; </p>

<form method="POST" action="process.php" >
 <table width="250"  align="center"  cellspacing="5px"  vspace="20px" style="border:solid thin"  >
   <tr> <td colspan="3" align="left" > Sign In </tr>
  <tr>
    <td width="30%" align="right">Usename</td>
    <td width="5%">&nbsp;</td>
    <td>
        <input type="text"  name="user">
    </td> </tr>
	 
	
    <tr>
    <td width="30%" align="right">Password</td>
    <td width="5%">&nbsp;</td>
    <td>
        <input type="password" name="pass">
    </td>
  </tr>
  
  <tr><td>&nbsp; </td> <td colspan="2"> <table width="100%"  >
  <tr>
    <td  align="right">
      <input type="submit" name="submit" value="SignIn">
    </td>
    <td width="1%"></td>
    <td>
      <input type="Reset" value="reset">
    </td>
  </tr>
</table>
</td></tr>
<tr> <td colspan="3" align="right" > &nbsp; <a href="signup.php" style="text-decoration:none">SignUp</a></td> </tr>
</table>

 
</form>
</body>

</html>