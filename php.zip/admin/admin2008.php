<?php

class admindbase
{

	var $dbhost='localhost';
	var $dbuser='root';
	var $dbpass='';
	var $dbname='dbsmtp';
	var $conn;
	var $rcset;
	
	function constructor()
	{
			 $this->conn=mysql_connect($this->dbhost,$this->dbuser,$this->dbpass) or die('MySql Connection Error :'.mysql_error()); 
			 mysql_select_db($this->dbname,$this->conn) or die('Database Connection Error :'.mysql_error());		
	}
		
	function __construct() 
	{	
		 $this->conn=mysql_connect($this->dbhost,$this->dbuser,$this->dbpass) or die('MySql Connection Error :'.mysql_error()); 
		 mysql_select_db($this->dbname,$this->conn) or die('Database Connection Error :'.mysql_error());			
	}
	
	function __readexecute($query)
	{
		$this->rcset=mysql_query($query,$this->conn) or  die('Query Syntax Error :');
	}
	
	
	
	function __read($query)
	{		
		$this->__readexecute($query);
		$set = array(); 		
		if( !empty($this->rcset) )
		{		
	 	while ( $row = mysql_fetch_array($this->rcset, MYSQL_ASSOC)  ) 
		     $set[]=$row;
		}	 
		return $set;		
	}
	
  function __write($query)
	{
		mysql_query($query,$this->conn);               
                $err=mysql_error($this->conn);
		$rs=mysql_affected_rows($this->conn);
                 
                if( $rs != 1 )
                     return $err;

		return $rs;
	}
	
  function __upcheck($user,$pass)
	 {   	    
	    $query="SELECT oemail,pass FROM  register where oemail='".$user."'"; 					
	    $rs=$this->__read($query);		    				
	    if(strcmp($rs[0]['oemail'],$user)==0 && strcmp($rs[0]['pass'],$pass)==0)
			   return 1;		   		   
			   
		  return 0; 		   
	 }
	
  function destructor()
	{
		if( !empty($this->rcset) )
		   mysql_free_result($this->rcset);
		   
		if( !empty($this->conn) )
		   mysql_close($this->conn);		   		
	}
	
	function __destruct()
	{	
		if( !empty($this->rcset) )
		   mysql_free_result($this->rcset);
		   
		//if( !empty($this->conn) )
		  // mysql_close($this->conn);		   		
	}
}

?>