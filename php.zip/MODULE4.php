<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="File-List" href="COMPOSER_files/filelist.xml">
<title>CLICK HERE</title>
<!--[if !mso]>
<style>
v\:*         { behavior: url(#default#VML) }
o\:*         { behavior: url(#default#VML) }
.shape       { behavior: url(#default#VML) }
</style>
<![endif]--><!--[if gte mso 9]>
<xml><o:shapedefaults v:ext="edit" spidmax="1027"/>
</xml><![endif]-->
</head>

<body bgcolor="#00FFFF">

<p><!--[if gte vml 1]><v:shapetype id="_x0000_t161"
 coordsize="21600,21600" o:spt="161" adj="4050" path="m,c7200@0,14400@0,21600,m,21600c7200@1,14400@1,21600,21600e">
 <v:formulas>
  <v:f eqn="prod #0 4 3"/>
  <v:f eqn="sum 21600 0 @0"/>
  <v:f eqn="val #0"/>
  <v:f eqn="sum 21600 0 #0"/>
 </v:formulas>
 <v:path textpathok="t" o:connecttype="custom" o:connectlocs="10800,@2;0,10800;10800,@3;21600,10800"
  o:connectangles="270,180,90,0"/>
 <v:textpath on="t" fitshape="t" xscale="t"/>
 <v:handles>
  <v:h position="center,#0" yrange="0,8100"/>
 </v:handles>
 <o:lock v:ext="edit" text="t" shapetype="t"/>
</v:shapetype><v:shape id="_x0000_s1028" type="#_x0000_t161" alt="WELCOME TO OHD'S REQUEST COMPOSER"
 style='width:516pt;height:36pt' adj="5665" fillcolor="red" strokecolor="yellow">
 <v:stroke dashstyle="1 1" endcap="round"/>
 <v:shadow color="#868686"/>
 <v:textpath style='font-family:"Impact";font-size:24pt;v-text-kern:t' trim="t"
  fitpath="t" xscale="f" string="WELCOME TO OHD'S REQUEST COMPOSER"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=691 height=45
src="COMPOSER_files/image001.gif" alt="WELCOME TO OHD'S REQUEST COMPOSER"
v:shapes="_x0000_s1028"><![endif]></p>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<img border="0" src="writing450.jpg" width="157" height="74"></p>
<HR color="#000000"></HR>
<div align="center">
  <center>
  <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="836" height="238" id="AutoNumber1">
    <tr>
      <td width="348" height="238">
      <p align="center">&nbsp;</p>
      <p align="center"><!--[if gte vml 1]><v:shapetype id="_x0000_t137"
 coordsize="21600,21600" o:spt="137" adj="4800" path="m0@0l7200,r7200,l21600@0m0@1l7200,21600r7200,l21600@1e">
 <v:formulas>
  <v:f eqn="val #0"/>
  <v:f eqn="sum 21600 0 @0"/>
 </v:formulas>
 <v:path textpathok="t" o:connecttype="rect"/>
 <v:textpath on="t" fitshape="t"/>
 <v:handles>
  <v:h position="topLeft,#0" yrange="3086,10800"/>
 </v:handles>
 <o:lock v:ext="edit" text="t" shapetype="t"/>
</v:shapetype><v:shape id="_x0000_s1030" type="#_x0000_t137" style='width:229.5pt;
 height:24.75pt' fillcolor="#9400ed" strokecolor="#eaeaea" strokeweight="1pt">
 <v:fill color2="blue" angle="-90" colors="0 #a603ab;13763f #0819fb;22938f #1a8d48;34079f yellow;47841f #ee3f17;57672f #e81766;1 #a603ab"
  method="none" type="gradient"/>
 <v:shadow on="t" type="perspective" color="silver" opacity="52429f" origin="-.5,.5"
  matrix=",46340f,,.5,,-4768371582e-16"/>
 <v:textpath style='font-family:"Arial Black";font-size:18pt;v-text-kern:t;
  v-same-letter-heights:t' trim="t" fitpath="t" string="TO VIWE THE REQUEST THAT ARE RECEIVED"/>
</v:shape><![endif]--><![if !vml]><img border=0 width=321 height=38
src="COMPOSER_files/image002.gif" alt="TO VIWE THE REQUEST THAT ARE RECEIVED"
v:shapes="_x0000_s1030"><![endif]></p>
      <p><font size="4"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <a href="../../My%20Documents/My%20Webs/vickram.gif">
      CLICK HERE </a></b></font></p>
      <p>&nbsp;</p>
      <p></p>
      <p><font size="4"><b>&nbsp;</b></font></p>
      <p><font size="4"><b>RELATED NEWS:</b></font></p>
      <p><font size="4" color="#800000"><b><MARQUEE>OHD HAS LAUNCHED RECENTLY IN VCE</MARQUEE></b></font></p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p></td>
      <td width="482" height="238">
      <form method="POST" action="--WEBBOT-SELF--">
        <!--webbot bot="SaveResults" u-file="C:\Documents and Settings\Administrator\My Documents\My Webs\_private\form_results.csv" s-format="TEXT/CSV" s-label-fields="TRUE" --><p>
        <b><font size="4">&nbsp;<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<form action="process.php" method="post" >
<table width="200" border="1" align="center">
  <tr>
    <td>From&nbsp;</td>
    <td>&nbsp;<input name="from" type="text" size="20" /></td>
  </tr>
  <tr>
    <td>To&nbsp;</td>
    <td>&nbsp;<input name="to" type="text" size="20" /></td>
  </tr>
  <tr>
    <td>Attach&nbsp;</td>
    <td>&nbsp;<input name="attach" type="file" size="20" /></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;<textarea name="" cols="80" rows="10"></textarea></td>
  </tr>
  
 <tr>  <td colspan="2" align="right"> <input name="submit" type="button"  value="Send"/>&nbsp;&nbsp;&nbsp;&nbsp;</td> </tr> 
</table>

</form>
</body>
</html>
</font></b></p>
      </form>
      <p>&nbsp;</td>
    </tr>
  </table>
  </center>
</div>
</body>

</html>