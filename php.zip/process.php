<?php

if( isset($_POST['submit']) )
{
	 $value=$_POST['submit'] ;	 
	 switch( $value)
	  {	  
	   case 'SignIn':
	        userpasschk();
			break;	
       case 'register':
	        newregister();
			break;						
		case 'send' :		
		    compose();
			break;			
																 			 
	  }	  
}  


function newregister()
{
  
  $user=$_POST['user'];
  $addr=$_POST['address'];	
  $oemail=$_POST['o-email'].'@vickram.net';
  $pass=$_POST['pass'];
  $rpass=$_POST['pass2'];	
  $bdate=$_POST['bdate'];
  $bmonth=$_POST['bmonth'];
  $byear=$_POST['byear'];
  $gender=$_POST['gender'];
  $prof=$_POST['menu2'];
  $dept=$_POST['menu3'];
     
if( !empty($user)  && !empty($oemail) && !empty($pass)  && ( strcmp($pass,$rpass)==0 ) && !empty($bdate)  && !empty($bmonth) && !empty($dept) && !empty($prof)  )
{
 include_once("admin/admin2008.php");
 $adb= new admindbase ();
 $query=sprintf("insert into register (user,address,oemail,pass,bdate,bmonth,byear,gender,profession,department)      		 values('%s','%s','%s','%s','%u','%u','%u','%s','%s','%s')",$user,$addr,$oemail,$pass,$bdate,$bmonth,$byear,$gender,$prof,$dept);  
if( $adb->__write($query) ==1 )
  {
  $_POST['sts']= $oemail." successfully created"; 
  include_once("status.php");
  }
else
  {
  $_POST['sts']= $oemail."  email already exist";
  include_once("status.php"); 
  }
}
else
  {
   $_POST['sts']= "some field data missing";
   include_once("status.php");
  }
      
}


function userpasschk()
{
  include_once("admin/admin2008.php");
  $adb= new admindbase ();
  
  $user=$_POST['user'];
  $pass=$_POST['pass'];	
  
  if( !empty($user) && !empty($pass) )
  {
  if($adb->__upcheck($user,$pass) == 1 )
   {
     retrive();
     return;	 
   }
  } 
  
  header("Location: index.php");     	     
}


function compose ()
{
    $attch="";
	$from=$_POST['from'] ;
	$to=$_POST['to'];
	$subj=$_POST['subj'];
	$body=$_POST['body'];
	$tfname=$_FILES['file']['tmp_name'];
	//$fname=$_FILES['file']['name'];
	//$ftype=$_FILES['file']['type'];
	
	
	if( !empty($from)  && !empty($to) && !empty($subj) && !empty($body)  ) 
    {
    include_once("admin/admin2008.php");
  	$adb= new admindbase ();	   					
	if( !empty($tfname) )		    
  	 $attch=setattach($tfname);		
	 
	$query=sprintf("insert into mails (source,dest,subject,attach,body) values('%s','%s','%s','%s','%s')",$from,$to,$subj,$attch,$body);	 
    if( $adb->__write($query) ==1 )
	  {
      $_POST['sts']= "email send to ". $to;
      include_once("status.php");  
	  }
    else
	  {
      $_POST['sts']= "email failed send to ". $to;
      include_once("status.php");  
	  }
   } 
 else
   { 
   $_POST['sts']= "field missing";
   include_once("status.php");  
   }
     
	
}

function setattach($tfname)
{		
	if($_FILES['file']['error'][0]==UPLOAD_ERR_OK)
	{
	   $size=filesize($tfname);	   
	   $fp=fopen($tfname,"r");	
	   $content=addslashes(fread($fp,$size));
	   fclose($fp);	 
	   return $content;
	}
	else
	  return "";		  	  	  
}


function retrive()
{

  include_once("admin/admin2008.php");
  $adb= new admindbase ();
  $user = $_POST['user'];   
  $query =sprintf( "select  * from mails where dest='%s'",$user);      
  $rs=$adb->__read($query);
  for ( $i=0; $i<count($rs); $i++) 
    echo $rs [$i]['source'] . "<a href=body.php?mailid=".$rs[$i]['skey'].">".$rs[$i]['subject']  ."</a> <br>";  	
}

?>


