<?php

 include_once("admin/admin2008.php");
 $adb= new admindbase ();
 
  $mid = $_GET['mailid'];   
  $query =sprintf( "select  * from mails where skey='%ld'",$mid);      
  $rs=$adb->__read($query);
  
    echo "From :". $rs[0]['source'] . "<br>";
	echo "To :".$rs[0]['dest'] ."<br>"; 
	echo "Subject :". $rs[0]['subject'] ."<br>"; 
	echo  $rs[0]['body'] ."<br>"; 
	echo  $rs[0]['attach'] ."<br>"; 
	
			   

?>