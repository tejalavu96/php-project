<footer id="pagefooter">
<div id="f-content">
<img src="images/bamboo.png" width="96" height="125" alt="bamboo" id="footerimg">
<div id="credits">
<p class="sitecredit"> 2012 @ All Rights Reserved | </p>
<p class="designcredit">Student Information System</p>

</div>
</div>

</footer>

</body>
</html>
