<!-- /*************************************************/ -->
<link rel="stylesheet" href="modal/windowfiles/dhtmlwindow.css" type="text/css" />
<script type="text/javascript" src="modal/windowfiles/dhtmlwindow.js">
</script>
<link rel="stylesheet" href="modal/modalfiles/modal.css" type="text/css" />
<script type="text/javascript" src="modal/modalfiles/modal.js"></script>
<!-- /*************************************************/ -->

<!-- /*************************************************/ -->
<script type="text/javascript">

function opennewsletter(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'courseinsert.php', 'Insert Course Details', 'width=550px,height=350px,center=1,resize=0,scrolling=1')

} //End "opennewsletter" function

function opensubject(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'subjectxx.php', 'Insert Subject', 'width=550px,height=450px,center=1,resize=0,scrolling=1')

} 

function openleture(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'lecture.php', 'Insert Lectures detail', 'width=550px,height=450px,center=1,resize=0,scrolling=1')

} 

function openstudent(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'studentins.php', 'Insert Student detail', 'width=550px,height=520px,center=1,resize=0,scrolling=1')

} 

function openadmin(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'addadmin.php', 'Insert admin detail', 'width=550px,height=520px,center=1,resize=0,scrolling=1')

} 

function openattendance(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'attendance.php', 'Insert Attendance detail', 'width=1000px,height=750px,center=1,resize=0,scrolling=1')

} 

function openexam(){
	emailwindow=dhtmlmodal.open('EmailBox', 'iframe', 'exam.php', 'Insert Marks detail', 'width=1000px,height=750px,center=1,resize=0,scrolling=1')

}
  </script>

<!-- /*************************************************/ -->